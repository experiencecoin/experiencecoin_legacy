<TS language="de_AT" version="2.0">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About Experiencecoin Core</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&lt;b&gt;Experiencecoin Core&lt;/b&gt; version</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>
This is experimental software.

Distributed under the MIT/X11 software license, see the accompanying file COPYING or http://www.opensource.org/licenses/mit-license.php.

This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit (http://www.openssl.org/) and cryptographic software written by Eric Young (eay@cryptsoft.com) and UPnP software written by Thomas Bernard.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copyright</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The Experiencecoin Core developers</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source> (%1-bit)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Double-click to edit address or label</source>
        <translation>Doppelklickn zan Editian vo da Adress und Titl</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Eazeig a neiche Adress</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Kopia de ausgwöhte Adress in de Zwischenoblog</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>Adress &amp;Kopian</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Leschn</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Very sending addresses</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Much receiving addresses</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>These are your Experiencecoin addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>These are your Experiencecoin addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>&amp;Titl Kopian</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Ändan</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Mid Beistrich &apos;trennte Weate (*.csv)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Titl</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adress</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>nixda</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Geheimwort-Eingabedialog</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Gib dei Geheimwuat ei</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Gib a neix Geheimwuat ei</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Und des gleiche noamoi</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>A neix Geheimwuat fias Beasl vagebn.&lt;br/&gt;Vawend dabei entweda &lt;b&gt;10 (oda mea) zufölliche Zeichn&lt;/b&gt; (oiso Buchstobn, Ziffan, Sondazeichn), oda &lt;b&gt;ocht (oda mea) gaunze Weata&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Vaschlissl &apos;s Beasl</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Dafia muasst dei Beasl mitm Geheimwuat aufspean.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Beasl aufspean</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Dafia musst des Beasl mitm Geheimwuat entschlissln.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Beasl entschlissln</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Geheimwuat ändan</translation>
    </message>
    <message>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>Gib des oite und des neiche Geheimwuat fias Beasl ei.</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Beasl-Vaschlisselung bschtätign</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR EXPERIENCECOINS&lt;/b&gt;!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Beasl is vaschlisslt</translation>
    </message>
    <message>
        <source>Experiencecoin Core will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your Experiencecoins from being stolen by malware infecting your computer.</source>
        <translation>Experiencecoin wiad si jetz vatschüssn um de Vaschlisselung obzschliaßn. Denk draun, doss di söbst de Vaschlisselung ned vua an Maleur schitzn kau, waunnst amoi a Ungeziefa (schadsoftware: viren, trojaner) auf dein Rechna host (oda losst).</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Vaschlisselung vom Beasl is föhgschlogn</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Vaschlisselung vom Beasl is wegn an inteanen Föhla föhgschlogn. Bleede Gschicht. Jetz is&apos; immano unvaschlisslt.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>howined gsogd: &lt;b&gt;des gleiche&lt;b/&gt; noamoi?</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Beasl aufspean is föhgschlogn</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Des Geheimwuat fias Beasl-Entschlissln woa owa sowos vo foisch.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Beasl-Entschlisselung is föhgschlogn</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>A Mödung untaschreim...</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Obgleichn midm Netz...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Iwasicht</translation>
    </message>
    <message>
        <source>Node</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Zeig de Gesaumt-Iwasicht iwa&apos;s Beasl</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Iwaweisungen</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Oite Iwaweisungen tscheckn</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;baba</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Baba und foi ned!</translation>
    </message>
    <message>
        <source>Show information about Experiencecoin Core</source>
        <translation>Zeig Infoamationen iwa Experiencecoin</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Iwa &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Zeig Infoamationen iwa Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Eistöllungen...</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&apos;s &amp;Beasl vaschlissln...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Sicharungskopie vom Beasl mochn...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Geheimwuat ändan...</translation>
    </message>
    <message>
        <source>Very &amp;sending addresses...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Much &amp;receiving addresses...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Importing blocks from disk...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Send coins to a Experiencecoin address</source>
        <translation>Schick Zasta aun a Experiencecoin Adress</translation>
    </message>
    <message>
        <source>Modify configuration options for Experiencecoin Core</source>
        <translation>Ända de Eistöllungen fia Experiencecoin</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Moch a Sichaheitskopie woaundas hin</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Des Geheimwuat fia Beasl-Vaschlisselung ändan</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>&amp;Debug Fensta</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Debug und Diagnose Konsole öffnen</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;Untaschrift tscheckn...</translation>
    </message>
    <message>
        <source>Experiencecoin</source>
        <translation>Experiencecoin</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Beasl</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Sign messages with your Experiencecoin addresses to prove you own them</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Experiencecoin addresses</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Datei</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Eistöllungen</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Hüfe</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Karteireita Werkzeigleistn</translation>
    </message>
    <message>
        <source>[testnet]</source>
        <translation>[testnetz]</translation>
    </message>
    <message>
        <source>Experiencecoin Core</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Request payments (generates QR codes and experiencecoin: URIs)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;About Experiencecoin Core</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Open a experiencecoin: URI or payment request</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show the Experiencecoin Core help message to get a list with possible Experiencecoin Core command-line options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Experiencecoin client</source>
        <translation>Experiencecoin Klient</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Experiencecoin network</source>
        <translation><numerusform>%n aktive Vabindung zum Netz</numerusform><numerusform>%n aktive Vabindungen zum Netz</numerusform></translation>
    </message>
    <message>
        <source>No block source available...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Processed %1 of %2 (estimated) blocks of transaction history.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Processed %1 blocks of transaction history.</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation type="unfinished"><numerusform/><numerusform/></translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation type="unfinished"><numerusform/><numerusform/></translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation type="unfinished"><numerusform/><numerusform/></translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation type="unfinished"><numerusform/><numerusform/></translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Error</source>
        <translation>Föhla</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Pass auf</translation>
    </message>
    <message>
        <source>Information</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Aktuö</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Aufhoin...</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Iwaweisung oogschickt</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Iwaweisung aun dii</translation>
    </message>
    <message>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Waunn: %1
Wiavü: %2
Wos: %3
Wohin: %4
</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>&apos;s Beasl is &lt;b&gt;vaschlisslt&lt;/b&gt; und deazeit grod &lt;b&gt;aufgschpeat&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>&apos;s Beasl is &lt;b&gt;vaschlisslt&lt;/b&gt; und deazeit grod &lt;b&gt;zuagschpeat&lt;/b&gt;</translation>
    </message>
    <message>
        <source>A fatal error occurred. Experiencecoin Core can no longer continue safely and will quit.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ClientModel</name>
    <message>
        <source>Network Alert</source>
        <translation>Netz Alarm</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Control Address Selection</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Quantität:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Betrog:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Obolus:</translation>
    </message>
    <message>
        <source>Low Output:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>After Fee:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Change:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>(un)select all</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Tree mode</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>List mode</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrog</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Address</source>
        <translation>Adress</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Waunn</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Bschtätigt</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Adress in&apos; Puffa kopian</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Titl in&apos; Puffa kopian</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Betrog in&apos; Puffa kopian</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Lock unspent</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Unlock unspent</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy fee</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy priority</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy low output</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy change</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>highest</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>higher</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>high</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>medium-high</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>medium</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>low-medium</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>low</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>lower</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>lowest</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>none</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Dust</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>yes</source>
        <translation>jo</translation>
    </message>
    <message>
        <source>no</source>
        <translation>na</translation>
    </message>
    <message>
        <source>This label turns red, if the transaction size is greater than 5000 bytes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>This means a fee of at least %1 per kB is required.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Can vary +/- 1 byte per input.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Transactions with higher priority are more likely to get included into a block.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>This label turns red, if the priority is smaller than &quot;medium&quot;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>This label turns red, if any recipient receives an amount smaller than %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>This means a fee of at least %1 is required.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Amounts below 0.546 times the minimum relay fee are shown as dust.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>This label turns red, if the change is smaller than %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>(no label)</source>
        <translation>nixda</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>(change)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Adress ändan</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Titl</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Adress</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Neiche Empfaungsadress</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Neiche Züü-Adress</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Empfaungs-Adress ändan</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Züü-Adress ändan</translation>
    </message>
    <message>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation>De eingebene Adress &quot;%1&quot; gibts eh scho im Adressbiachl.</translation>
    </message>
    <message>
        <source>The entered address &quot;%1&quot; is not a valid Experiencecoin address.</source>
        <translation>De eingebane Adress &quot;%1&quot; is a Kas.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>&apos;s Aufspean vom Beasl is föhgschlogn.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Neicha Schlissl hod ned eazeigt weadn kennan.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>Experiencecoin Core - Command-line options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Experiencecoin Core</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>version</source>
        <translation>veasion</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Vawendung:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>Kommandozeiln-Optionen</translation>
    </message>
    <message>
        <source>UI options</source>
        <translation>UI Optionen</translation>
    </message>
    <message>
        <source>Set language, for example &quot;de_DE&quot; (default: system locale)</source>
        <translation>de Sproch, am Bestn &quot;de_AT&quot; (sunsta: de Standard-Sproch auf dera Maschin)</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation>Mid minimiatn Fensta startn</translation>
    </message>
    <message>
        <source>Show splash screen on startup (default: 1)</source>
        <translation>Zeig a Willkommens-Fensterl beim Starten (waunn ned aundas aungebm: 1)</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: 0)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Welcome to Experiencecoin Core.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where Experiencecoin Core will store its data.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Experiencecoin Core will download and store a copy of the Experiencecoin block chain. At least %1GB of data will be stored in this directory, and it will grow over time. The wallet will also be stored in this directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Experiencecoin</source>
        <translation>Experiencecoin</translation>
    </message>
    <message>
        <source>Error: Specified data directory &quot;%1&quot; can not be created.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Error</source>
        <translation>Föhla</translation>
    </message>
    <message>
        <source>GB of free space available</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>(of %1GB needed)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>URI:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Select payment request file to open</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Eistöllungen</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;Masta</translation>
    </message>
    <message>
        <source>Optional transaction fee per kB that helps make sure your transactions are processed quickly. Most transactions are 1 kB.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Pay transaction &amp;fee</source>
        <translation>Iwaweisungs-Gebührn zoin</translation>
    </message>
    <message>
        <source>Automatically start Experiencecoin Core after logging in to the system.</source>
        <translation>Experiencecoin automatisch nochm Einloggn starten.</translation>
    </message>
    <message>
        <source>&amp;Start Experiencecoin Core on system login</source>
        <translation>Experiencecoin beim System-Einloggen starten</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>MB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Set the number of script verification threads (up to 16, 0 = auto, &lt;0 = leave that many cores free, default: 0)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change (experts only)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Connect to the Experiencecoin network through a SOCKS proxy.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Connect through SOCKS proxy (default proxy):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Active command-line options that override above options:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;Netzwerk</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>If you disable the spending of unconfirmed change, the change from a transaction cannot be used until that transaction has at least one confirmation. This also affects how your balance is computed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Automatically open the Experiencecoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Automatisch den Router fia &apos;n Experiencecoin port eistölln. Des geht nur, waunn da Router UPnP kaunn und waunns des durtn aa eigschoitn is.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Port mit UPnP zuweisen</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>Proxy &amp;IP:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Port:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Port vom Proxy (z.B. 9050)</translation>
    </message>
    <message>
        <source>SOCKS &amp;Version:</source>
        <translation>SOCKS &amp;Version:</translation>
    </message>
    <message>
        <source>SOCKS version of the proxy (e.g. 5)</source>
        <translation>SOCKS version vom Proxy (e.g. 5)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Fensta</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Zeig nur &apos;s Tray-Büderl, waunns Fensta minimiat wird.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>Minimier in&apos; Tray stott in&apos; Taskbar</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>Waunns Fensta gschlossn wiad, moch kaan Exitus, sondan minimier di afoch nua. Zum wiaklichn Beendn muass ma daunn im Menü auf &quot;baba und foi ned&quot; klickn.</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>Minimian stott Schliaßn</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>&amp;Anzeige</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>Sproch fias UI:</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting Experiencecoin Core.</source>
        <translation>De UI Sproch kaunn do gsetzt weadn. Auswiakn tuat si des owa eascht beim nächsten Start.</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>&amp;Weat-Einheit, in dea Beträge zeigt weadn:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Wöh de standard Unta-Einheit aus, mit der Beträge im UI und beim Vaschickn zeigt weadn.</translation>
    </message>
    <message>
        <source>Whether to show Experiencecoin addresses in the transaction list or not.</source>
        <translation>Ob Experiencecoin Adressn in da Iwaweisungslistn zeigt weadn soin, oda ned.</translation>
    </message>
    <message>
        <source>&amp;Display addresses in transaction list</source>
        <translation>Zeig Adressn in a Iwaweisungslistn</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Display coin &amp;control features (experts only)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Passt!</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Na Ned!</translation>
    </message>
    <message>
        <source>default</source>
        <translation>sunsta</translation>
    </message>
    <message>
        <source>none</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Client will be shutdown, do you want to proceed?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>De aungebane Proxy-Adress is a Kas.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Foamulaa</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Experiencecoin network after a connection is established, but this process has not completed yet.</source>
        <translation>De aunzeigtn Datn san meglichaweis ned aktuö. Dei Beasl gleicht si automatisch mitm Netz au, soboid a Vabindung aufrecht is, owa soweit samma no ned.</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Beasl</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Pending:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Immature:</source>
        <translation>Unreif:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>Gschiafta Betrog, dea no ned reif is</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;unlängste Iwaweisungen&lt;/b&gt;</translation>
    </message>
    <message>
        <source>out of sync</source>
        <translation>nimma aktuö</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>URI handling</source>
        <translation>URI Behaundlung</translation>
    </message>
    <message>
        <source>URI can not be parsed! This can be caused by an invalid Experiencecoin address or malformed URI parameters.</source>
        <translation>De URI is a Kas! Meglichaweis is de Experiencecoin Adress foisch, oda hoit sunst wos vamuakst.</translation>
    </message>
    <message>
        <source>Requested payment amount of %1 is too small (considered dust).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Payment request error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot start experiencecoin: click-to-pay handler</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Net manager warning</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Your active proxy doesn&apos;t support SOCKS5, which is required for payment requests via proxy.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Payment request fetch URL is invalid: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Payment request file handling</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Payment request file can not be read or processed! This can be caused by an invalid payment request file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Unverified payment requests to custom payment scripts are unsupported.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Refund from %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Error communicating with %1: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Payment request can not be parsed or processed!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Bad response from server %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Payment acknowledged</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Network request error</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Experiencecoin</source>
        <translation>Experiencecoin</translation>
    </message>
    <message>
        <source>Error: Specified data directory &quot;%1&quot; does not exist.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Error: Invalid combination of -regtest and -testnet.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Enter a Experiencecoin address (e.g. DJ7zB7c5BsB9UJLy1rKQtY7c6CQfGiaRLM)</source>
        <translation>Gib a Experiencecoin-Adress ei (sowos wia: DJ7zB7c5BsB9UJLy1rKQtY7c6CQfGiaRLM)</translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation>QR-Büderl speichan</translation>
    </message>
    <message>
        <source>PNG Image (*.png)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Client name</source>
        <translation>Klient Namen</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>Nix</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Klient Veasion</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Information</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>General</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Using OpenSSL version</source>
        <translation>Vawend OpenSSL in a Version</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Startzeit</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Netz</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Aunzoi von Vabindungen</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>Block-Kettn</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>Anzoi da Blöck</translation>
    </message>
    <message>
        <source>Estimated total blocks</source>
        <translation>Gschätzte Aunzoi da Blöck insgesaumt</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Zeit vom letztn Block</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Lodn</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Konsole</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Totals</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>In:</source>
        <translation>In:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Build date</source>
        <translation>Programm-Iwasetzunszeitpunkt</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Open the Experiencecoin Core debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Clear console</source>
        <translation>Konsole leermochn</translation>
    </message>
    <message>
        <source>Welcome to the Experiencecoin Core RPC console.</source>
        <translation>Heazlich willkomman zua Experiencecoin RPC Konsole.</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Vawend de Rauf- und Runta Tastn um bisherige Kommandos zruckzhoin, oder druck Strg-L zum Leschn.</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Gib &lt;b&gt;help&lt;/b&gt; ein fiara Iwasicht iwa olle Kommandos.</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>%1 KB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>%1 MB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>%1 GB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>%1 m</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>%1 h</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>%1 h %2 m</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Titl:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reuse one of the previously used receiving addresses. Reusing addresses has security and privacy issues. Do not use this unless re-generating a payment request made before.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the Experiencecoin network.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show</source>
        <translation>Zeig</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Titl in&apos; Puffa kopian</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Betrog in&apos; Puffa kopian</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Payment information</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>URI</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Address</source>
        <translation>Adress</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrog</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Titl</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Mödung</translation>
    </message>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>De URI is z&apos;laung. Tua hoit ned goa sovü fasln. </translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation>Föhla beim Eazeign vo an QR-Büderl fia de URI.</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>Waunn</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Titl</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Mödung</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrog</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>nixda</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>(no amount)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Vaschick Zasta</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Inputs...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>automatically selected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Quantität:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Betrog:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Obolus:</translation>
    </message>
    <message>
        <source>Low Output:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>After Fee:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Change:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Custom change address</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Vaschick Zasta glei aun mehrare auf aamoi</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>&amp;Ois Leschn</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Kontostaund:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Bschtätige de Iwaweisung</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Iwaweisung bschtätign</translation>
    </message>
    <message>
        <source>%1 to %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Betrog in&apos; Puffa kopian</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy priority</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy low output</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy change</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Total Amount %1 (= %2)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>or</source>
        <translation>oda</translation>
    </message>
    <message>
        <source>The recipient address is not valid, please recheck.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Waunnst nix vaschickn wüst, daunn loss&apos; hoit bleibm.</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>Des is mea ois wost host.</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>Ois zsamm und de Spesn vo %1 dazua is mea ois wost host.</translation>
    </message>
    <message>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation>A doppete Adress gfundn. (A jede Adress derfs immanua amoi in ana Iwaweisung gebm)</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Warning: Invalid Experiencecoin address</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>(no label)</source>
        <translation>nixda</translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Payment request expired</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid payment address %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>&amp;Betrog:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>wo&amp;hin:</translation>
    </message>
    <message>
        <source>The address to send the payment to (e.g. DJ7zB7c5BsB9UJLy1rKQtY7c6CQfGiaRLM)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Gib an Titl fia de neiche Adress</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Titl:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Eifügn da Adress ausm Puffa</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Message:</source>
        <translation>Mödung:</translation>
    </message>
    <message>
        <source>This is a verified payment request.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>A message that was attached to the experiencecoin: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the Experiencecoin network.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>This is an unverified payment request.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Pay To:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Memo:</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>Experiencecoin Core is shutting down...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>Mödung &amp;untaschreim</translation>
    </message>
    <message>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Duachs Untaschreim vo ana Mödung mit deina Adress stöllst kloa, dass du den Schlissl dazua host. Pass owa auf, dassd ned glei ois untaschreibsd wos da iangdana hinhoit, weu sunst kennts leicht passian, dassd vasehentlich kwasi an Blanko-Scheck untaschreibst. Untaschreib nua konkrete Mödungen denenst aa wiakli zuastimmst.</translation>
    </message>
    <message>
        <source>The address to sign the message with (e.g. DJ7zB7c5BsB9UJLy1rKQtY7c6CQfGiaRLM)</source>
        <translation>De Adress mit dera&apos;st untaschreibst (z.B. DJ7zB7c5BsB9UJLy1rKQtY7c6CQfGiaRLM)</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Eifügn da Adress ausm Puffa</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Gib de Mödung ei, de&apos;st untaschreibm wüst</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>De Untaschrift in den Puffa kopian</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Experiencecoin address</source>
        <translation>Untaschreib de Mödung, damid kloa is, dass de Adress dia gheat</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>Olle Föda zrucksetzn</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>&amp;Ois Leschn</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>&amp;Untaschrift tscheckn</translation>
    </message>
    <message>
        <source>Enter the signing address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack.</source>
        <translation>Gib de Untaschrifts-Adress, de Mödung und de Untaschrift ei. De Mödung muass auf Punkt und Beistrich (und Leerzeichn, Tabulatorn, Zeulnumbrüch, usw) gaunz genau des gleiche sein, wos untaschriem wuan is. Pass auf, dassd ned mea in de Mödung eineliest, ois wos wiakli drinsteht, sunst kenntast leicht auf an Schmäh einefoin.</translation>
    </message>
    <message>
        <source>The address the message was signed with (e.g. DJ7zB7c5BsB9UJLy1rKQtY7c6CQfGiaRLM)</source>
        <translation>De Adress, mit dera untaschriem wuan is (z.B. DJ7zB7c5BsB9UJLy1rKQtY7c6CQfGiaRLM)</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Experiencecoin address</source>
        <translation>Tscheck, doss de Mödung a wiakli mit da aungebanan Adress untaschriem wuan is</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>Olle Föda zrucksetzn</translation>
    </message>
    <message>
        <source>Enter a Experiencecoin address (e.g. DJ7zB7c5BsB9UJLy1rKQtY7c6CQfGiaRLM)</source>
        <translation>Gib a Experiencecoin-Adress ei (sowos wia: DJ7zB7c5BsB9UJLy1rKQtY7c6CQfGiaRLM)</translation>
    </message>
    <message>
        <source>Click &quot;Sign Message&quot; to generate signature</source>
        <translation>Klick auf &quot;Mödung untaschreim&quot; zum Untaschreim</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>De eingebane Adress is a Kas.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>Tscheck dassd Adress richtig is, und prowias noamoi.</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>De eingebene Adress gheat zu kaan Schlissl.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>Zu dera Adress howi kaan Schlissl gspeichat.</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation>&apos;s Untaschreim is föhgschlogn.</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>Mödung is untaschriem.</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation>De Untaschrift woara Kas.</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation>Tscheck dassd Untaschrift richtig is, und prowias noamoi.</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation>De Untaschrift passt ned zu dera Mödung.</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation>Iwaprifung da Untaschrift is föhgschlogn.</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation>De Untaschrift hod zua Mödung passt.</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>Experiencecoin Core</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The Experiencecoin Core developers</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Open until %1</source>
        <translation>Offn bis %1</translation>
    </message>
    <message>
        <source>conflicted</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>%1/offline</source>
        <translation>%1/koa netz</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/unbschtätigt</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 Bschtätigungan</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Zuastaund</translation>
    </message>
    <message numerus="yes">
        <source>, broadcast through %n node(s)</source>
        <translation><numerusform>, iwa %n Knotn vateult</numerusform><numerusform>, iwa %n Knotn vateult</numerusform></translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Waunn</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Kwöön</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation>Gschiaft</translation>
    </message>
    <message>
        <source>From</source>
        <translation>Vo</translation>
    </message>
    <message>
        <source>To</source>
        <translation>Aun</translation>
    </message>
    <message>
        <source>own address</source>
        <translation>eigane Adress</translation>
    </message>
    <message>
        <source>label</source>
        <translation>Titl</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation>eahoitena Betrog</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation><numerusform>eascht noch %n Block vawendboa</numerusform><numerusform>eascht noch %n Bleckn vawendboa</numerusform></translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation>ned aungnumman</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation>ausgebana Betrog</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>Iwaweisungsgebüa</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation>Untam Strich</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Mödung</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Bemeakung</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation>Iwaweisungs Nr</translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Generated coins must mature %1 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to &quot;not accepted&quot; and it won&apos;t be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Debug information</source>
        <translation>Debug Infoamation</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation>Iwaweisung</translation>
    </message>
    <message>
        <source>Inputs</source>
        <translation>Eingobn</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrog</translation>
    </message>
    <message>
        <source>true</source>
        <translation>woah</translation>
    </message>
    <message>
        <source>false</source>
        <translation>foisch</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>, is no ned eafoigreich oogschickt wuan.</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation type="unfinished"><numerusform/><numerusform/></translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>unbekaunnt</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Transaction details</source>
        <translation>Iwaweisungsdatn</translation>
    </message>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Do sichst de Einzlheitn fo dera Iwaweisung</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Waunn</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Oat</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adress</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrog</translation>
    </message>
    <message>
        <source>Immature (%1 confirmations, will be available after %2)</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation type="unfinished"><numerusform/><numerusform/></translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Offn bis %1</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>bschtätigt (%1 Bschtätigungen)</translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Den Block kaunnst da in d&apos; Hoa schmian!</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Eazeigt, owa ned aungnumman</translation>
    </message>
    <message>
        <source>Offline</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Confirming (%1 of %2 recommended confirmations)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Conflicted</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Received with</source>
        <translation>Empfaungen mid</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>Empfaungen vo</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>gschickt aun</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Aun di söbst</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>gschiaft</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(nix)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Zuastaund da Iwaweisung. Fia de Aunzoi da Bschtätigungan foah mid da Maus driwa.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Waunn de Iwaweisung einakumman is.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Oat da Iwaweisung.</translation>
    </message>
    <message>
        <source>Destination address of transaction.</source>
        <translation>Züü-Adress da Iwaweisung.</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Da Betrog, den wos&apos;d zoit oda kriagd host.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Ois</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Heit</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>de Wochn</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>den Monat</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>letztn Monat</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>des Joa</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Bereich...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Empfaungen mid</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Gsendet aun</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>Aun di söbst</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Gschiaft</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Aundare</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Suach noch ana Adress oda an Titl</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>klaaansta Betrog</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Adress in&apos; Puffa kopian</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Titl in&apos; Puffa kopian</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Betrog in&apos; Puffa kopian</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Titl ändan</translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation>Zeig de Einzlheitn vo da Iwaweisung</translation>
    </message>
    <message>
        <source>Export Transaction History</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>There was an error trying to save the transaction history to %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The transaction history was successfully saved to %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Beistrich &apos;trennte Weate (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Bschtätigt</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Waunn</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Oat</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Titl</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adress</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrog</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>Nr</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Bereich:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>bis</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>No wallet has been loaded.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>Vaschick Zasta</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The wallet data was successfully saved to %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>experiencecoin-core</name>
    <message>
        <source>Usage:</source>
        <translation>Vawendung:</translation>
    </message>
    <message>
        <source>List commands</source>
        <translation>Kommandos aunzeign</translation>
    </message>
    <message>
        <source>Get help for a command</source>
        <translation>Hüfe fiara Kommando</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Eistöllungen:</translation>
    </message>
    <message>
        <source>Specify configuration file (default: experiencecoin.conf)</source>
        <translation>Gib de Konfigurationsdatei aun (sunsta: experiencecoin.conf)</translation>
    </message>
    <message>
        <source>Specify pid file (default: experiencecoind.pid)</source>
        <translation>Datei, wo de Prozessnumma gspeichat wiad (sunsta: experiencecoind.pid)</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Vazeichnis fia de Datein</translation>
    </message>
    <message>
        <source>Set database cache size in megabytes (default: 25)</source>
        <translation>Zwischnspeichagreß fia de Datenbank in megabeits (sunsta: 25)</translation>
    </message>
    <message>
        <source>Listen for connections on &lt;port&gt; (default: 7300 or testnet: 17300)</source>
        <translation>Auf Vabindungen am &lt;port&gt; lauschn (sunsta: 7300 bzw. testnet: 17300)</translation>
    </message>
    <message>
        <source>Maintain at most &lt;n&gt; connections to peers (default: 125)</source>
        <translation>Hechstns &lt;n&gt; Vabindungen zu aundare Netz-Knotn aufrecht eahoitn (sunsta: 125)</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Vabind di mid an Netz-Knotn, owa frog nua noch aundare Knotn, danoch vapäulisia di wieda</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>Gib dei eigene öffentliche Adress aun</translation>
    </message>
    <message>
        <source>Threshold for disconnecting misbehaving peers (default: 100)</source>
        <translation>Geduidsfodnstärke gegniwa deppate Netz-Knotn (sunsta: 100)</translation>
    </message>
    <message>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: 86400)</source>
        <translation>Waunn Geduidsfodn amoi grissn, daunn wia long bis wieda guat (sunsta: 86400)</translation>
    </message>
    <message>
        <source>An error occurred while setting up the RPC port %u for listening on IPv4: %s</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: 7400 or testnet: 17400)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Hob a Uawaschl offn fia de Kommandozeuln und JSON-RPC Beföhle</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Ois Dämon im Hintagrund laafn und auf Beföhle lauschn</translation>
    </message>
    <message>
        <source>Use the test network</source>
        <translation>Des Test-Netz vawenden</translation>
    </message>
    <message>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect)</source>
        <translation>Nimm Vabindungen vo aussn aun (waunn nix aungebn is, güt 1, aussa waunn -proxy oda -connect optionen aungebm san)</translation>
    </message>
    <message>
        <source>%s, you must set a rpcpassword in the configuration file:
%s
It is recommended you use the following random password:
rpcuser=experiencecoinrpc
rpcpassword=%s
(you do not need to remember this password)
The username and password MUST NOT be the same.
If the file does not exist, create it with owner-readable-only file permissions.
It is also recommended to set alertnotify so you are notified of problems;
for example: alertnotify=echo %%s | mail -s &quot;Experiencecoin Alert&quot; admin@foo.com
</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Acceptable ciphers (default: TLSv1.2+HIGH:TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!3DES:@STRENGTH)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>An error occurred while setting up the RPC port %u for listening on IPv6, falling back to IPv4: %s</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot obtain a lock on data directory %s. Experiencecoin Core is probably already running.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Enter regression test mode, which uses a special chain in which blocks can be solved instantly. This is intended for regression testing tools and app development.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Enter regression test mode, which uses a special chain in which blocks can be solved instantly.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Error: The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Error: This transaction requires a transaction fee of at least %s because of its amount, complexity, or use of recently received funds!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation>A programmal startn, waunn si a unbstätigte Iwaweisung ändat. (a %s wiad dabei duachn Iwaweisungs-Hash easetzt)</translation>
    </message>
    <message>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services (default: -proxy)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Warning: -paytxfee is set very high! This is the transaction fee you will pay if you send a transaction.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Warning: Please check that your computer&apos;s date and time are correct! If your clock is wrong Experiencecoin Core will not work properly.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Warning: error reading wallet.dat! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Warning: wallet.dat corrupt, data salvaged! Original wallet.dat saved as wallet.{timestamp}.bak in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&lt;category&gt; can be:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Attempt to recover private keys from a corrupt wallet.dat</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Experiencecoin Core Daemon</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Experiencecoin Core RPC client version</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Block creation options:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Clear list of wallet transactions (diagnostic tool; implies -rescan)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Connect only to the specified node(s)</source>
        <translation>Nur mit de aungebanen Netz-Knotn vabindn.</translation>
    </message>
    <message>
        <source>Connect through SOCKS proxy</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Connect to JSON-RPC on &lt;port&gt; (default: 7400 or testnet: 17400)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Discover own IP address (default: 1 when listening and no -externalip)</source>
        <translation>Find söbst de eigane IP-Adress (waunn nix aungebn is: 1, aussa mit -externalip oda waunns Lauschn oisagaunza oodraht is)</translation>
    </message>
    <message>
        <source>Do not load the wallet and disable wallet RPC calls</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Error: Wallet locked, unable to create transaction!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Error: system error: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Föhla beim Lauschn aufn port. Waunn des so gwoit is, dann gib de Option -listen=0 aun.</translation>
    </message>
    <message>
        <source>Failed to read block info</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to read block</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to sync block index</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to write block index</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to write block info</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to write block</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to write file info</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to write to coin database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to write transaction index</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to write undo data</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Fee per kB to add to transactions you send</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Find peers using DNS lookup (default: 1 unless -connect)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Generate coins (default: 0)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>How many blocks to check at startup (default: 288, 0 = all)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>How thorough the block verification is (0-4, default: 3)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>If &lt;category&gt; is not supplied, output all debugging information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid -onion address: &apos;%s&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Prepend debug output with timestamp (default: 1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>RPC client options:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Rebuild block chain index from current blk000??.dat files</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Select SOCKS version for -proxy (4 or 5, default: 5)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Send command to Experiencecoin Core server</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Set maximum block size in bytes (default: %d)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Set the number of threads to service RPC calls (default: 4)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Spend unconfirmed change when sending transactions (default: 1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Start Experiencecoin Core server</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>This is intended for regression testing tools and app development.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Usage (deprecated, use experiencecoin-cli):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Wait for RPC server to start</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Wallet %s resides outside data directory %s</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Warning: Deprecated argument -debugnet ignored, use -debug=net</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex to change -txindex</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Imports blocks from external blk000??.dat file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</source>
        <translation>A programmal startn, waunn de Alarmglockn leitn, oda waunn de Block-Kettn oag vazweigt. (a %s wiad dabei duach a Nochricht easetzt)</translation>
    </message>
    <message>
        <source>Output debugging information (default: 0, supplying &lt;category&gt; is optional)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: %d)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Set the number of script verification threads (up to 16, 0 = auto, &lt;0 = leave that many cores free, default: 0)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Information</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid amount for -minrelaytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid amount for -mintxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Maintain a full transaction index (default: 0)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: 5000)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: 1000)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Only accept block chain matching built-in checkpoints (default: 1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Only connect to nodes in network &lt;net&gt; (IPv4, IPv6 or Tor)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>SSL options: (see the Bitcoin Wiki for SSL setup instructions)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Protokoi anstott in de Datei debug.log liawa direkt aussaschreibn</translation>
    </message>
    <message>
        <source>Set minimum block size in bytes (default: 0)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Specify connection timeout in milliseconds (default: 5000)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>System error: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Transaction amounts must be positive</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 0)</source>
        <translation>Vawend UPnP um den Lausch-Port zuzuweisn (sunsta: 0)</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 1 when listening)</source>
        <translation>Vawend UPnP um den Lausch-Port zuzuweisn (wenn nix aungebm is: 1, wenns Lauschn eigschoitn is)</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Benutza fia JSON-RPC Vabindungen</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Pass auf</translation>
    </message>
    <message>
        <source>Warning: This version is obsolete, upgrade required!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Zapping all transactions from wallet...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>version</source>
        <translation>veasion</translation>
    </message>
    <message>
        <source>wallet.dat corrupt, salvage failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Geheimwuat fia JSON-RPC Vabindungen</translation>
    </message>
    <message>
        <source>Allow JSON-RPC connections from specified IP address</source>
        <translation>JSON-RPC Beföhle nua vo da aungebanen Netz-Adress ealaubn</translation>
    </message>
    <message>
        <source>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)</source>
        <translation>Beföhle zum Netz-Knotn mit da &lt;ip&gt;-Adress schickn (sunsta: 127.0.0.1)</translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>A programmal startn, waunn si wos am bestn Block ändat. (a %s wiad dabei duachn Block-Hash easetzt)</translation>
    </message>
    <message>
        <source>Upgrade wallet to latest format</source>
        <translation>&apos;s Beasl ins neichaste Foamat bringan</translation>
    </message>
    <message>
        <source>Set key pool size to &lt;n&gt; (default: 100)</source>
        <translation>Schlisslvorratsgreß auf &lt;n&gt; setzn (sunsta: 100)</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>De gaunze Block-kettn noch föhlende Iwaweisungen oosuachn</translation>
    </message>
    <message>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>Vawend OpenSSL (https) fia JSON-RPC Vabindungan</translation>
    </message>
    <message>
        <source>Server certificate file (default: server.cert)</source>
        <translation>Söawa Zeatifikatsdatei (sunsta: server.cert)</translation>
    </message>
    <message>
        <source>Server private key (default: server.pem)</source>
        <translation>Söawa Privatschlissl (sunsta: server.pem)</translation>
    </message>
    <message>
        <source>This help message</source>
        <translation>Dea Hüfe-Text</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer (bind returned error %d, %s)</source>
        <translation>Kaun mi ned aun %s auf dera Maschin draunhängan (bind returned error %d, %s)</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>Ealaub DNS nochfrogn fia -addnode, -seednode und -connect</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Adressbiachl lodn...</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>Föhla beim Lodn vom Beasl: &apos;s Beasl is leida hinnich</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet requires newer version of Experiencecoin Core</source>
        <translation>Föhla beim Lodn vom Beasl: fia des Beasl brauchst a neichare Experiencecoin veasion</translation>
    </message>
    <message>
        <source>Wallet needed to be rewritten: restart Experiencecoin Core to complete</source>
        <translation>&apos;s Beasl hod neich gschriem weadn miassn: beend des Programmal und starts noamoi zum Featigmochn</translation>
    </message>
    <message>
        <source>Error loading wallet.dat</source>
        <translation>Föhla beim Lodn vom Beasl (wallet.dat)</translation>
    </message>
    <message>
        <source>Invalid -proxy address: &apos;%s&apos;</source>
        <translation>Ungültige &quot;-proxy&quot; Adress: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: &apos;%s&apos;</source>
        <translation>Des Netzwerk in -onlynet is a Kas: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Unknown -socks proxy version requested: %i</source>
        <translation>De valongte -socks proxy version is ned bekaunnt: %i</translation>
    </message>
    <message>
        <source>Cannot resolve -bind address: &apos;%s&apos;</source>
        <translation>Kaunn de -bind Adressn ned auflösn: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Cannot resolve -externalip address: &apos;%s&apos;</source>
        <translation>Kaunn de -externalip Adressn ned auflösn: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Da Betrog fia -paytxfee=&lt;amount&gt; is a Kas: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Invalid amount</source>
        <translation>Ungültiga Betrog</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Sovü host goaned</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Block index lodn...</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>An Netz-Knotn aufnehman, und bei da Staungan hoitn</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer. Experiencecoin Core is probably already running.</source>
        <translation>Konnt mi ned aun %s auf dera Maschin aunhängan. Meglichaweis rennt des Programmal scho.</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Beasl lodn...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>Zrucksteign geht nimma beim Beasl</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>De Easotz Adress kaunn ned gschriem weadn</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Noch-tscheckn...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Featig midm Lodn</translation>
    </message>
    <message>
        <source>To use the %s option</source>
        <translation>Um de Option %s z&apos;vawendn</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Föhla</translation>
    </message>
    <message>
        <source>You must set rpcpassword=&lt;password&gt; in the configuration file:
%s
If the file does not exist, create it with owner-readable-only file permissions.</source>
        <translation>Du muasst rpcpassword=&lt;password&gt; in da Konfigurationsdatei:
%s
setzn. Waunns de Datei no ned gibt, daunn eazeigs so, dass&apos; ka aundara lesn kau.</translation>
    </message>
</context>
</TS>